# ======= Imports =======
from typing import TypedDict, Annotated
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
import pandas as pd
from Collection_Agent import  collecting_incident
from Assign_Agent import Catagorize_incidents
import time

# ======= State Definition =======
class State(TypedDict):
    messages: Annotated[list, add_messages]
    high_priority_incidents: list
    low_priority_incidents: list

# ======= Agent Nodes =======
def ATT(state: State):
    print("📥 Incident fetching agent activated...")
    
    # Fetch incidents
    state = collecting_incident()

    return state

def Catogarizing(state: State):
    print("📥 Catogarize the incident...")
    result = Catagorize_incidents() 
    return state

# ======= Build Workflow =======
workflow = StateGraph(State)

# Add nodes
workflow.add_node("fetch_incidents", ATT)
workflow.add_node("catogarize",Catogarizing)
# Add other nodes as needed, e.g., low_prioritizing, solution_finding

# Add edges
workflow.add_edge(START, "fetch_incidents")
workflow.add_edge("fetch_incidents","catogarize")
# Define other edges as required
workflow.add_edge("catogarize", END)

# Compile workflow
app = workflow.compile()

# ======= Run Workflow =======
if __name__ == "__main__":
    while True:
        print("🚀 Running Multi-Agent Incident Management Workflow...")

        # Initial state
        initial_state = {"messages": []}

        # Run workflow
        result = app.invoke(initial_state)

        print("\n✅ Workflow Completed Successfully!\n")
        print("🗒️ Messages & Results:")
        for msg in result["messages"]:
            print(msg)
        time.sleep(30)
