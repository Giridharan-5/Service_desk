# ServiceDesk-Automation

Ticket generation chatbot used for Ticket generation in service now.
