import pandas as pd
from langchain_community.llms import Ollama


import pandas as pd
from langchain_community.llms import Ollama

def Catagorize_incidents():
    # ===== Load CSV =====
    CSV_FILE_PATH = r"C:\Users\Giridharan\Desktop\ServiceDesk-Automation-main\incidents.csv"
    df = pd.read_csv(CSV_FILE_PATH)

    # ===== Initialize LLM =====
    llm = Ollama(model="llama3.2", temperature=0)

    # ===== Define keywords mapping =====
    keywords_to_category = {
        "database": "Database",
        "power": "Power / Electrical",
        "network": "Network",
        "internet": "Network",
        "VPN": "Network",
        "storage": "Storage",
        "CRAC": "Cooling / Environmental",
        "backup": "Backup / Restore",
        "portal": "Software / Portal",
        "workflow": "ITSM / Process",
        
        # Add more as needed
    }

    # ===== Map categories to people =====
    category_to_person = {
        "Database": "Giridharan",
        "Network": "Dhanush",
        "Power / Electrical": "Kalyan",
        "Storage": "Akash",
        "Cooling / Environmental": "Giridharan",
        "Backup / Restore": "Dhanush",
        "Software / Portal": "Dhanush",
        "ITSM / Process": "Kalyan",
        "Other": "Akash"
    }

    # ===== Categorize description =====
    def categorize_description(description):
        desc_lower = str(description).lower()
        
        # Keyword-based first
        for kw, cat in keywords_to_category.items():
            if kw.lower() in desc_lower:
                return cat
        
        # Fallback to LLM
        prompt = f"""
        You are an IT Service Desk assistant.

        Task: Categorize the following incident description into **one and only one** of these categories:

        Database, Network, Power/Electrical, Storage, Cooling/Environmental, Backup/Restore, ITSM/Process, Software/Portal, Other.

        Instructions:
        - Read the incident description carefully.
        - Select the **most appropriate category** from the list above.
        - If the description does not clearly fit any category, choose "Other".
        - Respond **with only the category name**, no explanations, punctuation, or extra text.

        Incident Description: "{description}"
        """
        response = llm.invoke(prompt)
        return response.strip()

    # ===== Apply categorization =====
    df['Assignment Group'] = df['Description'].apply(categorize_description)

    # ===== Assign people based on category =====
    df['Assigned To'] = df['Assignment Group'].apply(lambda x: category_to_person.get(x, "Giridharan"))

    # ===== Save to CSV =====
    OUTPUT_CSV = r"C:\Users\Giridharan\Desktop\ServiceDesk-Automation-main\Assigned_incidents.csv"
    df.to_csv(OUTPUT_CSV, index=False)

    print(f"✅ Categorization and assignment completed. Saved to {OUTPUT_CSV}")
    return {"message":f"Categorization and assignment completed. Saved to {OUTPUT_CSV}"}




