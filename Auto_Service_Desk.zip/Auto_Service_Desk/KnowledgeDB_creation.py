# Import necessary modules from LangChain
from langchain_classic.document_loaders import PyMuPDFLoader # To load PDF files
from langchain_text_splitters import RecursiveCharacterTextSplitter  # To split the text into chunks
from langchain_classic.embeddings import HuggingFaceBgeEmbeddings # To create embeddings using Hugging Face models
from langchain_classic.vectorstores import Chroma  # To create and persist the vector database

# Stage 1: Load the PDF file
def load_the_pdf(file_path):
    loader = PyMuPDFLoader(file_path)  # Initialize the PDF loader with the provided file path
    documents = loader.load()  # Load the PDF content into a list of documents
    print("PDF loaded successfully.")  # Print success message
    return documents  # Return the loaded documents

# Stage 2: Split the documents into smaller chunks
def split_the_documents(documents):
    # Initialize the text splitter with chunk size and overlap settings
    text_splitter = RecursiveCharacterTextSplitter(chunk_size=400, chunk_overlap=100, separators=["\n\n", "\n", " ", ""])
    chunks = text_splitter.split_documents(documents)  # Split the documents into chunks
    print(f"Documents split into {len(chunks)} chunks.")  # Print the number of chunks
    return chunks  # Return the chunks

# Stage 3: Create embeddings for the document chunks
def create_embeddings():
    # Use a pre-trained embedding model from Hugging Face
    embedding_model = HuggingFaceBgeEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")  
    print("Embeddings model created.")  # Print success message
    return embedding_model  # Return the embedding model

# Stage 4: Create a vector database from the document chunks and embeddings
def create_vector_db(chunks, embedding_model, db_path):
    # Create a Chroma vector database from the document chunks and embeddings, and persist it to the specified directory
    vector_db = Chroma.from_documents(documents=chunks, embedding=embedding_model, persist_directory=db_path)
    vector_db.persist()  # Persist the vector database to disk
    print("Vector database created and persisted.")  # Print success message

# Main execution
if __name__ == "__main__":
    pdf_path = "./Data/PowerShell-guide.pdf"  # Path to the PDF file
    db_path = "./Vector_DB/guidlines.db"  # Path to store the vector database
    documents = load_the_pdf(pdf_path)  # Load the PDF documents
    chunks = split_the_documents(documents)  # Split the documents into chunks
    embedding_model = create_embeddings()  # Create the embeddings model
    create_vector_db(chunks, embedding_model, db_path)  # Create and persist the vector database
