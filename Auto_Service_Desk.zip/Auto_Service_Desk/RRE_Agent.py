
import streamlit as st
from langchain_ollama import OllamaLLM
#from langchain.chains.retrieval_qa.base import RetrievalQA
from langchain_classic.chains import RetrievalQA
from langchain_ollama import OllamaEmbeddings
from langchain_community.vectorstores import Chroma
import os
import pandas as pd
from langchain_core.prompts import PromptTemplate

# ========= Environment Setup =========
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# ========= Streamlit UI =========
st.set_page_config(page_title="IT Incident RAG Assistant", layout="wide")
st.title("💡 IT Service Desk - Helper")

# ========= 1️⃣ Setup Paths =========
DB_PERSIST_PATH = r"C:\Users\Giridharan\Desktop\ServiceDesk-Automation-main\Vector_DB"
CSV_FILE_PATH = r"C:\Users\Giridharan\Desktop\ServiceDesk-Automation-main\Assigned_incidents.csv"

# ========= 2️⃣ Load Embedding Model =========
embedding_model = OllamaEmbeddings(model="mxbai-embed-large")
st.success("✅ Ollama embedding model loaded.")

# ========= 3️⃣ Load FAISS Vector Store =========
if os.path.exists(DB_PERSIST_PATH):
    vectordb=Chroma(embedding_function=embedding_model, persist_directory=DB_PERSIST_PATH)
    #vectordb = Chroma(persist_directory=DB_PERSIST_PATH, embedding_function=embedding_model)
    st.success("✅ Chroma vector store loaded successfully.")
else:
    st.error(f"No Chroma database found at: {DB_PERSIST_PATH}")
    st.stop()

# ========= 4️⃣ Initialize LLM =========
llm = OllamaLLM(model="llama3.2", temperature=0.6)
st.success("✅ LLM loaded.")

# ========= 5️⃣ Define Custom Prompt =========
prompt_template = """
You are an IT Service Desk assistant.

Context from retrieved documents:
{context}

Question: {question}

Instructions:
- Use the context to answer if possible.
- If the context does not contain relevant information, provide your own relevant answer based on general IT Service Desk knowledge.
- Be concise and accurate.
"""

PROMPT = PromptTemplate(
    template=prompt_template,
    input_variables=["context", "question"]
)

# ========= 6️⃣ Create RetrievalQA Chain (with Prompt + Retrieval Visibility) =========
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=vectordb.as_retriever(search_kwargs={"k": 4}),  # retrieve top 4 documents
    return_source_documents=True,
    chain_type_kwargs={"prompt": PROMPT}  # ✅ Inject custom prompt
)

# ========= 7️⃣ Load Incident Dataset =========
df = pd.read_csv(CSV_FILE_PATH)

# ========= Sidebar Filters =========
st.sidebar.header("Filter Incidents")

# Filter by Assignment Group
assignment_groups = df['assignment_group'].dropna().unique().tolist()
selected_group = st.sidebar.selectbox("Select Assignment Group", ["All"] + assignment_groups)

if selected_group != "All":
    df_filtered = df[df['assignment_group'] == selected_group]
else:
    df_filtered = df.copy()

# Filter by Priority
priorities = df_filtered['priority'].dropna().unique().tolist()
selected_priority = st.sidebar.selectbox("Select Priority", ["All"] + priorities)

if selected_priority != "All":
    df_filtered = df_filtered[df_filtered['priority'] == selected_priority]

# Select Incident
incident_numbers = df_filtered['Incident_Id'].tolist()
selected_incident_number = st.sidebar.selectbox("Select Incident", incident_numbers)

# ========= Display Incident Details =========
selected_incident = df[df['Incident_Id'] == selected_incident_number].iloc[0]
short_description = selected_incident['description']

st.subheader(f"Incident: {selected_incident_number}")
st.write(f"**Short Description:** {short_description}")
st.write(f"**Created On:** {selected_incident['Created_On']}")
st.write(f"**Updated On:** {selected_incident['Updated_On']}")
st.write(f"**State:** {selected_incident['State']}")
st.write(f"**Priority:** {selected_incident['priority']}")
st.write(f"**Assignment Group:** {selected_incident['assignment_group']}")
st.write(f"**Assigned To:** {selected_incident['Assigned_To']}")
# ========= 8️⃣ Query Input and RAG Solution =========
query = st.text_area("🔍 Enter a query or use the short description:", value=short_description, height=100)

if st.button("Get Solution"):
    with st.spinner("Fetching possible solution..."):
        result = qa_chain.invoke({"query": query})

        # ====== Display Final Answer ======
        st.success("✅ Possible Solution Found:")
        st.write(result["result"])

        # ====== Detailed Retrieval Output ======
        if "source_documents" in result:
            st.subheader("📄 Retrieved Context Documents")
            for i, doc in enumerate(result["source_documents"], start=1):
                with st.expander(f"🔹 Document {i}"):
                    st.markdown(f"**Content:**\n\n{doc.page_content}")
                    if hasattr(doc, "metadata") and doc.metadata:
                        st.markdown("**Metadata:**")
                        st.json(doc.metadata)

        # ====== YES / NO Buttons to Update Knowledge Database ======
        st.subheader("Do you want to update the knowledge database with this solution?")
        col1, col2 = st.columns(2)

        with col1:
            if st.button("✅ YES"):
                st.success("Knowledge database updated successfully!")
                # TODO: Add logic to append to CSV / Chroma if required

        with col2:
            if st.button("❌ NO"):
                st.info("Knowledge database not updated.")
