import os
import requests
from dotenv import load_dotenv
import pandas as pd
from requests.auth import HTTPBasicAuth

# Load environment variables
load_dotenv()

SERVICENOW_INSTANCE = os.getenv("SERVICENOW_INSTANCE")
SERVICENOW_USER = os.getenv("SERVICENOW_USER")
SERVICENOW_PASS = os.getenv("SERVICENOW_PASS")
CALLER_NAME = os.getenv("CALLER_NAME")
TABLE = os.getenv("TABLE", "incident")  # Default to incident table

def collecting_incident():
    # ServiceNow REST API URL for table API
    url = f"{SERVICENOW_INSTANCE}/api/now/table/{TABLE}"

    # Query parameters to filter by caller_name and select specific fields
    params = {
        'sysparm_query': f'caller_id.name={CALLER_NAME}',
        'sysparm_fields': (
            'number,short_description,description,caller_id,urgency,impact,priority,'
            'contact_type,assignment_group,assigned_to,state,sys_created_on,sys_updated_on'
        ),
        'sysparm_limit': 100  # adjust limit as needed
    }

    # Make GET request
    response = requests.get(
        url,
        auth=HTTPBasicAuth(SERVICENOW_USER, SERVICENOW_PASS),
        params=params
    )

    if response.status_code == 200:
        data = response.json().get('result', [])
        if data:
            # Convert JSON data to pandas DataFrame
            df = pd.DataFrame(data)

            # Rename columns for readability
            df.rename(columns={
                'number': 'Incident ID',
                'short_description': 'Short Description',
                'description': 'Description',
                'caller_id': 'Caller',
                'urgency': 'Urgency',
                'impact': 'Impact',
                'priority': 'Priority',
                'contact_type': 'Contact Type',
                'assignment_group': 'Assignment Group',
                'assigned_to': 'Assigned To',
                'state': 'State',
                'sys_created_on': 'Created On',
                'sys_updated_on': 'Updated On'
            }, inplace=True)

            # Extract display values for nested dict fields
            for col in ['Caller', 'Assignment Group', 'Assigned To']:
                if col in df.columns:
                    df[col] = df[col].apply(
                        lambda x: x.get('display_value') if isinstance(x, dict) else x
                    )

            # Save to CSV
            output_file = "incidents.csv"
            df.to_csv(output_file, index=False, encoding='utf-8-sig')

            print(f"✅ {len(df)} incidents found for caller '{CALLER_NAME}'")
            return {"message": f"📁 Data saved to: {os.path.abspath(output_file)}"}
        else:
            return {"message": f"No incidents found for caller '{CALLER_NAME}'"}
    else:
        print(f"❌ Failed to fetch incidents. Status Code: {response.status_code}")
        return {"message": f"{response.text}"}

# Example usage
if __name__ == "__main__":
    result = collecting_incident()
    print(result)
