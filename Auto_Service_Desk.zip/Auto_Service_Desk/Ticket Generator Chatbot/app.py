from flask import Flask, render_template, request, redirect, session, jsonify
from dotenv import load_dotenv
import os
import requests
import re, json
from langchain_community.llms import Ollama
from langchain_core.prompts import PromptTemplate

load_dotenv()
app = Flask(__name__)
app.secret_key = "supersecretkey"

# ServiceNow credentials
SERVICENOW_INSTANCE = os.getenv("SERVICENOW_INSTANCE")
SERVICENOW_USER = os.getenv("SERVICENOW_USER")
SERVICENOW_PASS = os.getenv("SERVICENOW_PASS")
CALLER_ID = os.getenv("CALLER_ID", "Giridharan")

# Initialize LLM
llm = Ollama(model="llama3.2")

prompt_template = """
You are the finest ServiceNow ticket creation assistant.
Generate a professional, detailed, and clear incident ticket.
Based on the short description below, output a strictly valid JSON with all fields:
- description: detailed and comprehensive ticket description
- impact: 1 (high) to 3 (low)
- urgency: 1 (high) to 3 (low)
- priority: 1 (critical) to 4 (low)
- category: e.g., inquiry, software, hardware, access, network
- contact_type: e.g., email, phone, chat
- keywords: relevant keywords summarizing the issue

Short Description: "{short_desc}"
Return strictly JSON only.
"""

def parse_llm_json(output):
    output = re.sub(r"```json|```", "", output, flags=re.IGNORECASE)
    match = re.search(r"\{.*\}", output, re.DOTALL)
    if match:
        try:
            return json.loads(match.group())
        except:
            return {}
    return {}

def get_ticket_fields(short_desc):
    prompt = PromptTemplate(input_variables=["short_desc"], template=prompt_template)
    output = llm.invoke(prompt.format(short_desc=short_desc))
    return parse_llm_json(output)

def create_servicenow_ticket(short_desc, fields):
    url = f"{SERVICENOW_INSTANCE}/api/now/table/incident"
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    payload = {
        "short_description": short_desc,
        "description": fields.get("description", short_desc),
        "impact": fields.get("impact", "3"),
        "urgency": fields.get("urgency", "3"),
        "priority": fields.get("priority", "4"),
        "category": fields.get("category", "inquiry"),
        "contact_type": fields.get("contact_type", "email"),
        "caller_id": CALLER_ID,
        "u_keywords": fields.get("keywords", "")
    }
    resp = requests.post(url, auth=(SERVICENOW_USER, SERVICENOW_PASS),
                         headers=headers, json=payload)
    return resp.json()

@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        # Simple authentication for demo
        if username == "palanisamy" and password == "password":
            session["user"] = username
            return redirect("/chat")
    return render_template("login.html")

@app.route("/chat")
def chat():
    if "user" not in session:
        return redirect("/")
    return render_template("chat.html")

@app.route("/send_message", methods=["POST"])
def send_message():
    data = request.json
    user_msg = data.get("message")
    # Generate ticket fields
    fields = get_ticket_fields(user_msg)
    # Create ServiceNow ticket
    ticket = create_servicenow_ticket(user_msg, fields)
    return jsonify({"reply": f"Ticket created successfully! Ticket ID: {ticket['result']['number']}"})


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("user", None)  # Clear the user from session
    return redirect("/")



if __name__ == "__main__":
    app.run(debug=True)
