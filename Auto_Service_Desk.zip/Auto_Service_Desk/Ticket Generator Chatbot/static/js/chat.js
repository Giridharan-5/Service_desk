document.addEventListener('DOMContentLoaded', () => {
    const messageInput = document.getElementById('message-input');
    const sendButton = document.getElementById('send-button');
    const chatMessages = document.getElementById('chat-messages');
    const ticketList = document.getElementById('ticket-list');
    const noTicketsMsg = document.getElementById('no-tickets');
    const refreshTimeSpan = document.getElementById('refresh-time');

    // Initial fetch
    fetchTickets();
    
    // Auto-refresh tickets every 30 seconds
    setInterval(fetchTickets, 30000);

    // Send message handlers (unchanged from previous)
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });

    function sendMessage() {
        const message = messageInput.value.trim();
        if (!message) return;

        addMessage('user', message);
        messageInput.value = '';
        const bubbling = addBubbling();

        fetch('/send_message', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        })
        .then(response => response.json())
        .then(data => {
            bubbling.remove();
            addMessage('bot', data.reply);
            fetchTickets();  // Refresh tickets after creation
        })
        .catch(error => {
            console.error('Error:', error);
            bubbling.remove();
            addMessage('bot', 'Sorry, something went wrong.');
        });
    }

    // ... (addMessage, addBubbling, getCurrentTime, scrollToBottom functions unchanged)

    function fetchTickets() {
        fetch('/get_tickets')
        .then(response => response.json())
        .then(data => {
            ticketList.innerHTML = '';
            const tickets = data.tickets || [];
            
            if (tickets.length === 0) {
                noTicketsMsg.style.display = 'block';
            } else {
                noTicketsMsg.style.display = 'none';
                tickets.forEach(ticket => {
                    const li = document.createElement('li');
                    const createdDate = formatDate(ticket.sys_created_on || ticket.created);
                    li.innerHTML = `
                        <div class="ticket-number">${ticket.number}</div>
                        <div class="ticket-desc">${ticket.short_description}</div>
                        <div class="ticket-date">${createdDate}</div>
                    `;
                    ticketList.appendChild(li);
                });
            }
            
            // Update refresh timestamp
            refreshTimeSpan.textContent = getCurrentTime();
        })
        .catch(error => {
            console.error('Error fetching tickets:', error);
            noTicketsMsg.textContent = 'Error loading tickets.';
            noTicketsMsg.style.display = 'block';
        });
    }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        const date = new Date(dateStr);
        const now = new Date();
        const diffMs = now - date;
        const diffMins = Math.floor(diffMs / 60000);
        if (diffMins < 60) return `${diffMins}m ago`;
        const diffHours = Math.floor(diffMins / 60);
        if (diffHours < 24) return `${diffHours}h ago`;
        return date.toLocaleDateString();
    }

    // Existing functions: addMessage, addBubbling, getCurrentTime, scrollToBottom
    function addMessage(sender, text) {
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('message', sender);
        messageDiv.innerHTML = `
            <p>${text}</p>
            <span class="timestamp">${getCurrentTime()}</span>
        `;
        chatMessages.appendChild(messageDiv);
        scrollToBottom();
    }

    function addBubbling() {
        const bubblingDiv = document.createElement('div');
        bubblingDiv.classList.add('bubbling', 'bot');
        bubblingDiv.innerHTML = `
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        `;
        chatMessages.appendChild(bubblingDiv);
        scrollToBottom();
        return bubblingDiv;
    }

    function getCurrentTime() {
        const now = new Date();
        return now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
});